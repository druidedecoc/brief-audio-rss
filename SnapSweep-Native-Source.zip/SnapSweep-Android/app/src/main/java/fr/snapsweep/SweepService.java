package fr.snapsweep;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Deterministic rule-based automation. Interacts only with explicitly selected names. */
public final class SweepService extends AccessibilityService {
    public static volatile SweepService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private View overlay;
    private LinearLayout overlayActions;
    private TextView feedback;
    private boolean scanning=false, working=false, busy=false;
    private String pendingName="", status="Prêt";
    private int stage=0, quota=Integer.MAX_VALUE, processedInBatch=0, scanPages=0, emptyPages=0;
    private long stageTime=0, lastTick=0;
    private int searchDirection=1, searchSteps=0;
    private final Set<String> scannedPageFingerprints=new LinkedHashSet<>();

    private static class Row {
        String name;
        AccessibilityNodeInfo target;
        Rect rect = new Rect();
        Row(String name, AccessibilityNodeInfo target) {
            this.name=name;this.target=target;target.getBoundsInScreen(rect);
        }
    }
    private int dp(float n) { return (int)(getResources().getDisplayMetrics().density*n+.5f); }
    private GradientDrawable bg(int c) { GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(12));return d; }

    @Override protected void onServiceConnected() {
        super.onServiceConnected(); instance=this;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        createOverlay();
    }
    @Override public void onDestroy() {
        stopAll();hideOverlay();instance=null;super.onDestroy();
    }
    @Override public void onInterrupt() { stopAll(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if(e==null) return;
        String pkg=e.getPackageName()==null?"":e.getPackageName().toString();
        boolean target=pkg.equals(Store.pkg(this));
        if(target) {
            showOverlay();
            if((scanning||working) && SystemClock.uptimeMillis()-lastTick>350) {
                lastTick=SystemClock.uptimeMillis(); handler.postDelayed(this::tick,180);
            }
        } else if(!pkg.equals(getPackageName())) {
            if(working) pause("Application quittée : traitement suspendu");
            if(!scanning) hideOverlay();
        } else {
            // Accessibility overlay events also come from our package. The active root
            // remains the other app, so do not hide our own floating controls here.
            AccessibilityNodeInfo active=getRootInActiveWindow();
            if(active!=null && getPackageName().contentEquals(active.getPackageName())) hideOverlay();
        }
    }
    private void createOverlay() {
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(9),dp(10),dp(9),dp(9));panel.setBackground(bg(0xff10223b));
        feedback=new TextView(this);feedback.setTextColor(Color.WHITE);feedback.setTextSize(11);
        feedback.setMaxLines(3);feedback.setText("SnapSweep · prêt");
        feedback.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        panel.addView(feedback);
        Button expand=new Button(this);expand.setAllCaps(false);expand.setText("☰ Commandes  ▾");
        expand.setTextColor(Color.WHITE);expand.setTextSize(12);expand.setBackground(bg(0xff294666));
        panel.addView(expand,new LinearLayout.LayoutParams(-1,dp(34)));
        overlayActions=new LinearLayout(this);overlayActions.setOrientation(LinearLayout.VERTICAL);
        overlayActions.setVisibility(View.GONE);panel.addView(overlayActions);
        expand.setOnClickListener(v->{
            boolean show=overlayActions.getVisibility()!=View.VISIBLE;
            overlayActions.setVisibility(show?View.VISIBLE:View.GONE);
            expand.setText(show?"☰ Commandes  ▴":"☰ Commandes  ▾");
        });
        addButton(overlayActions,"Scanner tout",()->{overlayActions.setVisibility(View.GONE);scanAll();});
        addButton(overlayActions,"Page suivante",()->{overlayActions.setVisibility(View.GONE);scanNextPage();});
        addButton(overlayActions,"Test : 1 seule",()->{overlayActions.setVisibility(View.GONE);startDelete(1);});
        addButton(overlayActions,"Supprimer sélection",()->{overlayActions.setVisibility(View.GONE);startDelete(Integer.MAX_VALUE);});
        addButton(overlayActions,"ARRÊTER",this::stopAll);
        addButton(overlayActions,"Voir la sélection",()->{
            stopAll();Intent i=new Intent(this,MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            dp(192), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.BOTTOM|Gravity.RIGHT;lp.x=dp(7);lp.y=dp(90);
        overlay=panel;overlay.setTag(lp);
        updateStatus("Prêt · ouvre la liste de conversations");
    }
    private void addButton(LinearLayout panel,String s,Runnable r) {
        Button b=new Button(this); b.setText(s);b.setTextSize(11);b.setAllCaps(false);
        b.setTextColor(s.equals("ARRÊTER")?0xffffb4b4:Color.WHITE);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(bg(s.equals("ARRÊTER")?0xff7b2940:0xff294666));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(38));p.topMargin=dp(5);
        panel.addView(b,p);b.setOnClickListener(v->r.run());
    }
    private void showOverlay() {
        if(wm==null||overlay==null||overlay.getParent()!=null)return;
        try {wm.addView(overlay,(WindowManager.LayoutParams)overlay.getTag());}catch(Exception ignored) { }
    }
    private void hideOverlay() {
        if(wm!=null&&overlay!=null&&overlay.getParent()!=null) {
            try {wm.removeViewImmediate(overlay);}catch(Exception ignored) { }
        }
    }
    private void updateStatus(String s) {
        status=s;
        if(feedback!=null)feedback.setText(Store.mode(this)+" · "+s+"\n"+
            Store.names(this,"found").size()+" trouvées · "+Store.remaining(this).size()+" en attente");
    }
    private AccessibilityNodeInfo targetRoot() {
        AccessibilityNodeInfo r=getRootInActiveWindow();
        if(r==null||r.getPackageName()==null||!Store.pkg(this).equals(r.getPackageName().toString()))return null;
        return r;
    }
    private void scanAll() {
        stopAll();scanning=true;scanPages=0;emptyPages=0;scannedPageFingerprints.clear();
        updateStatus("Analyse en cours...");tick();
    }
    private void scanNextPage() {
        stopAll();AccessibilityNodeInfo root=targetRoot();
        if(root==null){updateStatus("Ouvre d'abord la liste correcte");return;}
        collectPage(root);
        if(scroll(root))updateStatus("Page suivante : relance Scanner tout");
        else updateStatus("Impossible de faire défiler cette liste");
    }
    private void collectPage(AccessibilityNodeInfo root) {
        List<Row> rows=getRows(root);
        for(Row r:rows) if(!containsName(Store.names(this,"found"),r.name)) Store.add(this,"found",r.name);
    }
    private boolean containsName(List<String> names,String name) {
        for(String s:names)if(Store.norm(s).equals(Store.norm(name)))return true;
        return false;
    }
    private void startDelete(int limit) {
        if(scanning)scanning=false;
        if(Store.remaining(this).isEmpty()){updateStatus("Rien de coché : configure la sélection");return;}
        if(targetRoot()==null){updateStatus("Ouvre la liste de "+Store.mode(this));return;}
        working=true;busy=false;quota=limit;processedInBatch=0;pendingName="";stage=0;
        searchDirection=1;searchSteps=0;
        updateStatus(limit==1?"TEST d'une conversation":"Suppression sélectionnée en cours");
        tick();
    }
    public void stopAll() {
        working=false;scanning=false;busy=false;stage=0;pendingName="";
        updateStatus("Arrêté");
    }
    private void pause(String cause) {
        scanning=false;working=false;busy=false;stage=0;
        updateStatus("PAUSE · "+cause);
    }
    private void tick() {
        if(busy || (!scanning && !working))return;
        busy=true;
        try {
            AccessibilityNodeInfo root=targetRoot();
            if(root==null){pause("écran non disponible");return;}
            if(scanning) {
                List<Row> rows=getRows(root);
                if(rows.isEmpty()) {pause("aucune conversation reconnue sur cet écran");return;}
                int before=Store.names(this,"found").size();
                collectPage(root);scanPages++;
                int after=Store.names(this,"found").size();
                String fingerprint=rows.get(0).name+"/"+rows.get(rows.size()-1).name;
                if(after==before||!scannedPageFingerprints.add(fingerprint))emptyPages++;else emptyPages=0;
                updateStatus("Analyse : "+after+" conversations détectées");
                if(scanPages>=40||emptyPages>=2) {scanning=false;updateStatus("Analyse terminée · vérifier la sélection");return;}
                if(scroll(root)) handler.postDelayed(this::tick,850);
                else {scanning=false;updateStatus("Fin de la liste · vérifier la sélection");}
                return;
            }
            if(working) progress(root);
        } finally { busy=false; }
    }
    private void progress(AccessibilityNodeInfo root) {
        if(processedInBatch>=quota) {pause("test terminé · vérifier le résultat");return;}
        if(stage!=0 && SystemClock.uptimeMillis()-stageTime>6500){pause("menu inattendu · aucune autre action effectuée");return;}
        List<Row> rows=getRows(root);
        if(stage==0) {
            List<String> remaining=Store.remaining(this);
            if(remaining.isEmpty()) {pause("sélection traitée");return;}
            Row found=null;
            // Only operate on the exact selected conversation label, never on adjacent rows.
            for(Row r:rows) if(containsName(remaining,r.name)) {
                if(found==null)found=r; else if(Store.norm(found.name).equals(Store.norm(r.name))) {
                    pause("doublon de nom ambigu : "+r.name);return;
                }
            }
            if(found==null) {
                // Try both ends of the list, but cap search to avoid an endless loop.
                if(++searchSteps>85){pause("sélection introuvable après parcours complet");return;}
                boolean moved=scroll(root,searchDirection);
                if(!moved && searchDirection>0) {
                    searchDirection=-1; moved=scroll(root,searchDirection);
                }
                if(moved){updateStatus("Recherche des noms cochés...");handler.postDelayed(this::tick,850);}
                else pause("sélection introuvable dans cette liste");
                return;
            }
            searchSteps=0;
            if(Store.protectedName(this,found.name)) {pause("contact protégé");return;}
            pendingName=found.name;
            if(Store.mode(this).equals(Store.SNAP)) {
                // Require an actual control corresponding to the same row; no blind coordinates.
                if(!tap(found.target)){pause("bouton Effacer inaccessible pour "+pendingName);return;}
                stage=3;
            }else{
                boolean result=longPress(found);
                if(!result){pause("appui long impossible pour "+pendingName);return;}
                stage=2;
            }
            stageTime=SystemClock.uptimeMillis();
            updateStatus("Action : "+pendingName);
            handler.postDelayed(this::tick,750);
            return;
        }
        if(stage==2) {
            AccessibilityNodeInfo item=findDeleteMenu(root,false);
            if(item!=null&&tap(item)) {
                stage=3;stageTime=SystemClock.uptimeMillis();
                handler.postDelayed(this::tick,700);
            }else handler.postDelayed(this::tick,500);
            return;
        }
        if(stage==3) {
            AccessibilityNodeInfo confirm=findDeleteMenu(root,true);
            if(confirm!=null&&tap(confirm)) {
                stage=4;stageTime=SystemClock.uptimeMillis();
                handler.postDelayed(this::tick,900);return;
            }
            if(Store.mode(this).equals(Store.SNAP) && !containsNameRows(rows,pendingName)
                && SystemClock.uptimeMillis()-stageTime>950) {
                complete();return;
            }
            handler.postDelayed(this::tick,550);
            return;
        }
        if(stage==4) {
            // Clicking a confirmation is the measurable result; receipt by the server cannot be asserted.
            complete();
        }
    }
    private boolean containsNameRows(List<Row> rows,String name) {
        for(Row r:rows)if(Store.norm(r.name).equals(Store.norm(name)))return true;
        return false;
    }
    private void complete() {
        Store.add(this,"done",pendingName);
        processedInBatch++;pendingName="";stage=0;
        updateStatus("Confirmation effectuée · "+processedInBatch+" traitée(s)");
        handler.postDelayed(this::tick,900);
    }

    private boolean tap(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo cur=node;
        Rect origin=new Rect();node.getBoundsInScreen(origin);
        for(int i=0;cur!=null && i<3;i++,cur=cur.getParent()) {
            Rect b=new Rect();cur.getBoundsInScreen(b);
            // Never tap a whole list/container as a fallback for a tiny delete icon.
            if(b.height()>Math.max(dp(120),origin.height()*3))break;
            if(cur.isClickable())return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        return false;
    }
    private boolean longPress(Row row) {
        if(row.target.isLongClickable() && row.target.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK))return true;
        Rect r=row.rect;
        if(r.isEmpty())return false;
        Path path=new Path();path.moveTo(r.centerX(),r.centerY());
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path,0,900)).build();
        return dispatchGesture(g,null,null);
    }
    private AccessibilityNodeInfo findDeleteMenu(AccessibilityNodeInfo root,boolean confirmation) {
        List<AccessibilityNodeInfo> all=new ArrayList<>();flatten(root,all,0);
        if(confirmation) {
            boolean hasCancel=false;
            for(AccessibilityNodeInfo n:all) {
                String t=Store.norm(label(n));
                if(t.equals("annuler")||t.equals("cancel")||t.equals("not now")) {
                    hasCancel=true; break;
                }
            }
            // Without a recognizable confirmation dialog, never guess where to tap.
            if(!hasCancel) return null;
        }
        for(AccessibilityNodeInfo n:all) {
            String label=label(n).trim().toLowerCase(Locale.ROOT);
            if(label.isEmpty())continue;
            if(confirmation) {
                if(!(label.equals("supprimer")||label.equals("delete")||label.equals("confirmer")
                    ||label.equals("effacer")||label.equals("clear")
                    ||label.equals("delete chat")||label.equals("supprimer la conversation")
                    ||label.equals("supprimer la discussion")))continue;
            } else {
                if(!(label.equals("supprimer")||label.equals("delete")||label.equals("delete chat")
                    ||label.equals("supprimer la conversation")||label.equals("supprimer la discussion")))continue;
            }
            Rect r=new Rect();n.getBoundsInScreen(r);
            if(r.isEmpty()||!n.isVisibleToUser())continue;
            AccessibilityNodeInfo click=n;
            for(int i=0;i<3&&click!=null;i++,click=click.getParent()) if(click.isClickable())return click;
        }
        return null;
    }
    private String label(AccessibilityNodeInfo n) {
        if(n==null)return "";
        if(n.getText()!=null && n.getText().length()>0)return n.getText().toString();
        if(n.getContentDescription()!=null)return n.getContentDescription().toString();
        return "";
    }
    private void flatten(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out,int depth) {
        if(n==null||depth>22||out.size()>2500)return;
        out.add(n);
        for(int i=0;i<n.getChildCount();i++) flatten(n.getChild(i),out,depth+1);
    }
    private int screenWidth() {return getResources().getDisplayMetrics().widthPixels;}
    private int screenHeight(){return getResources().getDisplayMetrics().heightPixels;}
    private boolean validName(String name) {
        String s=Store.norm(name);
        if(s.length()<2||s.length()>70||s.matches("^[0-9 :./]+$"))return false;
        for(String bad:new String[]{"chats","discussions","discussion","rechercher","search","facebook","messenger",
            "actif","active","groupes","groups","stories","story","appels","calls","réglages","settings",
            "supprimer","delete","effacer","clear","archive","archiver","nouveau message","new message"})
            if(s.equals(bad)) return false;
        return true;
    }
    private List<String> childTexts(AccessibilityNodeInfo n) {
        ArrayList<AccessibilityNodeInfo> all=new ArrayList<>();flatten(n,all,0);
        LinkedHashSet<String> texts=new LinkedHashSet<>();
        for(AccessibilityNodeInfo child:all) {
            if(child.getText()!=null && child.getText().length()>0) {
                String t=child.getText().toString().trim(); if(!t.isEmpty())texts.add(t);
            }
        }
        return new ArrayList<>(texts);
    }
    private List<Row> getRows(AccessibilityNodeInfo root) {
        return Store.mode(this).equals(Store.SNAP)?snapRows(root):messRows(root);
    }
    private List<Row> snapRows(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> all=new ArrayList<>();flatten(root,all,0);
        LinkedHashMap<String,Row> rows=new LinkedHashMap<>();
        int w=screenWidth(), h=screenHeight();
        for(AccessibilityNodeInfo n:all) {
            Rect b=new Rect();n.getBoundsInScreen(b);
            if(b.isEmpty()||!n.isVisibleToUser()||b.centerX()<w*0.60||b.centerY()<h*.09)continue;
            String id=n.getViewIdResourceName()==null?"":n.getViewIdResourceName().toLowerCase(Locale.ROOT);
            String s=Store.norm(label(n));
            boolean looksLikeDelete=s.equals("×")||s.equals("x")||s.equals("✕")||s.equals("✖")
                ||s.contains("clear conversation")||s.contains("effacer la conversation")||s.contains("clear chat")
                ||s.contains("remove conversation")||id.contains("clear_conversation")||id.contains("remove_conversation");
            // Unlabelled right-hand small icon: only accept with a clear name in its parent row.
            boolean rightIcon=(s.isEmpty() && n.isClickable() && b.width()<dp(75)&&b.height()<dp(80));
            if(!looksLikeDelete&&!rightIcon)continue;
            AccessibilityNodeInfo anc=n.getParent();
            for(int level=0;anc!=null&&level<3;level++,anc=anc.getParent()) {
                Rect parentRect=new Rect();anc.getBoundsInScreen(parentRect);
                if(parentRect.width()<w*.56 || parentRect.height()>dp(155) || parentRect.height()<dp(38))continue;
                List<String> texts=childTexts(anc);
                if(texts.size()>4)continue;
                String candidate="";
                for(String t:texts)if(validName(t)&&!Store.norm(t).equals(s)){candidate=t;break;}
                if(!candidate.isEmpty()) {
                    rows.putIfAbsent(Store.norm(candidate),new Row(candidate,n));break;
                }
            }
        }
        return new ArrayList<>(rows.values());
    }
    private List<Row> messRows(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> all=new ArrayList<>();flatten(root,all,0);
        LinkedHashMap<String,Row> rows=new LinkedHashMap<>();
        int w=screenWidth(),h=screenHeight();
        for(AccessibilityNodeInfo n:all) {
            Rect r=new Rect();n.getBoundsInScreen(r);
            if(!n.isVisibleToUser()||r.width()<w*.62||r.height()<dp(51)||r.height()>dp(170)
                ||r.centerY()<h*.12||r.centerY()>h*.94)continue;
            List<String> texts=childTexts(n);
            // Messenger may expose rows as clickable rather than long-clickable.
            // Require multiple child labels in that case, then ask the user to verify.
            if(!n.isLongClickable() && !(n.isClickable() && texts.size()>=2))continue;
            if(texts.isEmpty()||texts.size()>8)continue;
            String candidate="";
            for(String t:texts)if(validName(t)){candidate=t;break;}
            if(!candidate.isEmpty()) rows.putIfAbsent(Store.norm(candidate),new Row(candidate,n));
        }
        return new ArrayList<>(rows.values());
    }
    private boolean scroll(AccessibilityNodeInfo root) { return scroll(root,1); }
    private boolean scroll(AccessibilityNodeInfo root,int direction) {
        ArrayList<AccessibilityNodeInfo> all=new ArrayList<>();flatten(root,all,0);
        AccessibilityNodeInfo best=null;int height=0;
        for(AccessibilityNodeInfo node:all) {
            Rect r=new Rect();node.getBoundsInScreen(r);
            if(node.isScrollable() && r.height()>screenHeight()*.35 && r.height()>height) {
                best=node;height=r.height();
            }
        }
        return best!=null && best.performAction(direction>0?
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
    }
}

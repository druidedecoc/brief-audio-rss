package fr.snapsweep;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(14, 27, 46);
    private static final int BLUE = Color.rgb(38, 100, 235);
    private static final int MUTED = Color.rgb(98, 110, 127);
    private static final int PALE = Color.rgb(244, 247, 251);
    private LinearLayout root, results;
    private EditText protectEdit;
    private TextView status;
    private int dp(float n) { return (int)(getResources().getDisplayMetrics().density * n + .5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        render();
    }
    @Override public void onResume() { super.onResume(); if(root != null) refresh(); }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable s = new GradientDrawable(); s.setColor(color); s.setCornerRadius(dp(radius)); return s;
    }
    private TextView text(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        if(bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, dp(4), 0, dp(4));
        return v;
    }
    private LinearLayout panel() {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17),dp(15),dp(17),dp(15)); card.setBackground(shape(Color.WHITE, 16));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin=dp(13);
        root.addView(card,p); return card;
    }
    private Button button(String label, Runnable run, boolean primary) {
        Button b = new Button(this); b.setText(label); b.setTextSize(13); b.setAllCaps(false);
        b.setTextColor(primary ? Color.WHITE : BLUE); b.setBackground(shape(primary? BLUE : 0xffebf1ff, 11));
        b.setPadding(dp(10), dp(7), dp(10), dp(7));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(47)); p.topMargin=dp(8);
        b.setLayoutParams(p); b.setOnClickListener(v->run.run()); return b;
    }
    private void render() {
        ScrollView sc = new ScrollView(this); sc.setFillViewport(true); sc.setBackgroundColor(PALE);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(17),dp(30),dp(17),dp(28)); sc.addView(root); setContentView(sc);
        root.addView(text("SnapSweep", 30, NAVY, true));
        root.addView(text("Nettoyage local · Snapchat + Messenger", 13, MUTED, false));

        LinearLayout first = panel();
        first.addView(text("1. Choisir l'application", 17, NAVY, true));
        LinearLayout modeRow = new LinearLayout(this); modeRow.setOrientation(LinearLayout.HORIZONTAL); first.addView(modeRow);
        for(String target : new String[]{Store.SNAP, Store.MESS}) {
            Button m = new Button(this); m.setText(target); m.setTextSize(13); m.setAllCaps(false);
            m.setTextColor(Store.mode(this).equals(target)?Color.WHITE:BLUE);
            m.setBackground(shape(Store.mode(this).equals(target)?BLUE:0xffe9effe,10));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,dp(48),1); p.rightMargin=dp(5);
            modeRow.addView(m,p); m.setOnClickListener(v->{
                if(SweepService.instance != null) SweepService.instance.stopAll();
                Store.mode(this,target); render();
            });
        }
        status=text("",12,MUTED,false); first.addView(status);
        first.addView(button("Activer l'accessibilité Android", ()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)),false));

        LinearLayout second=panel(); second.addView(text("2. Conversations à conserver",17,NAVY,true));
        second.addView(text("Un nom exact par ligne. Ces contacts sont systématiquement exclus.",12,MUTED,false));
        protectEdit=new EditText(this); protectEdit.setText(Store.protects(this));
        protectEdit.setTextSize(15); protectEdit.setMinLines(3); protectEdit.setMaxLines(7);
        protectEdit.setGravity(Gravity.TOP); protectEdit.setHint("Exemple :\nAlice Martin\nGroupe famille");
        protectEdit.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        protectEdit.setPadding(dp(12),dp(10),dp(12),dp(10)); protectEdit.setBackground(shape(PALE,10));
        second.addView(protectEdit,new LinearLayout.LayoutParams(-1,-2));
        second.addView(button("Enregistrer les exceptions",()->{Store.protects(this,protectEdit.getText().toString()); refresh(); Toast.makeText(this,"Exceptions enregistrées",Toast.LENGTH_SHORT).show();},false));

        LinearLayout third=panel(); third.addView(text("3. Scanner les conversations",17,NAVY,true));
        String directions=Store.mode(this).equals(Store.SNAP)
            ? "Dans Snapchat : Profil → ⚙ Réglages → Ma confidentialité et données → Effacer les données → Effacer les conversations."
            : "Dans Messenger : onglet Discussions (liste des conversations).";
        third.addView(text(directions,13,MUTED,false));
        third.addView(text("Lance ensuite « Scanner tout » sur la barre flottante. Reviens ici pour vérifier la sélection.",12,MUTED,false));
        third.addView(button("Ouvrir "+Store.mode(this),this::openTarget,true));
        third.addView(button("Réinitialiser l'analyse",()->new AlertDialog.Builder(this)
            .setTitle("Réinitialiser ?").setMessage("Effacer la sélection locale (aucune conversation n'est touchée) ?")
            .setNegativeButton("Annuler",null).setPositiveButton("Réinitialiser",(d,w)->{
                if(SweepService.instance!=null) SweepService.instance.stopAll();
                Store.clearScans(this);refresh();
            }).show(),false));

        LinearLayout fourth=panel(); fourth.addView(text("4. Vérifier la sélection",17,NAVY,true));
        fourth.addView(text("Seuls les noms cochés seront traités. Si la détection est incorrecte, ne lance pas la suppression.",12,MUTED,false));
        fourth.addView(button("Tout cocher sauf les exceptions",()->{saveProtect();Store.selectAllExceptProtected(this);refresh();},false));
        fourth.addView(button("Tout décocher",()->{Store.save(this,"selected",java.util.Collections.emptyList());refresh();},false));
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);fourth.addView(results);
        fourth.addView(button("Retourner dans "+Store.mode(this)+" pour supprimer",()->{
            saveProtect(); int count=Store.remaining(this).size();
            if(count==0) {Toast.makeText(this,"Aucune conversation sélectionnée",Toast.LENGTH_LONG).show();return;}
            new AlertDialog.Builder(this)
                .setTitle("Confirmer la sélection")
                .setMessage(count+" conversation(s) cochée(s). Les conversations protégées seront ignorées. Ouvre la liste, puis utilise le bouton flottant « Test 1 » ou « Démarrer ». Ce traitement peut être irréversible sur Messenger.")
                .setNegativeButton("Annuler",null)
                .setPositiveButton("Ouvrir",(dialog,which)->openTarget())
                .show();
        },true));
        root.addView(text("Aucun accès au compte, aucune connexion réseau, aucun message copié. L'accessibilité peut lire le contenu affiché : désactive le service après utilisation.",11,MUTED,false));
        refresh();
    }
    private void saveProtect() { if(protectEdit!=null) Store.protects(this,protectEdit.getText().toString()); }
    private void refresh() {
        if(status!=null) {
            boolean active=SweepService.instance!=null;
            status.setText((active?"● Service actif":"○ Service inactif")+" · "+Store.names(this,"found").size()+" détectées · "+Store.remaining(this).size()+" à supprimer · "+Store.names(this,"done").size()+" validées");
        }
        if(results!=null) {
            results.removeAllViews();
            List<String> names=Store.names(this,"found");
            if(names.isEmpty()) results.addView(text("Aucune conversation analysée pour l'instant.",13,MUTED,false));
            for(String name:names) {
                boolean protectedName=Store.protectedName(this,name);
                CheckBox check=new CheckBox(this);check.setText(name+(protectedName?" · conservée":"")+ (Store.done(this,name)?" · traitée":""));
                check.setTextSize(14);check.setChecked(!protectedName && Store.selected(this,name));
                check.setEnabled(!protectedName && !Store.done(this,name));check.setPadding(0,dp(6),0,dp(6));
                check.setOnCheckedChangeListener((v,checked)->Store.toggleSelected(this,name,checked));results.addView(check);
            }
        }
    }
    private void openTarget() {
        saveProtect();
        Intent i=getPackageManager().getLaunchIntentForPackage(Store.pkg(this));
        if(i==null) {Toast.makeText(this,"Application non installée ou introuvable",Toast.LENGTH_LONG).show();return;}
        try {startActivity(i);} catch(Exception e) {Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
    }
}

package fr.snapsweep;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.Locale;

/** All conversation labels remain on this Android device. */
public final class Store {
    public static final String SNAP = "Snapchat";
    public static final String MESS = "Messenger";
    private static final String PREF = "sweep_local_v1";
    private Store() {}

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    public static String mode(Context c) { return sp(c).getString("mode", SNAP); }
    public static void mode(Context c, String s) { sp(c).edit().putString("mode", s).apply(); }
    public static String pkg(Context c) { return mode(c).equals(MESS) ? "com.facebook.orca" : "com.snapchat.android"; }
    public static String protects(Context c) { return sp(c).getString("protected", ""); }
    public static void protects(Context c, String text) { sp(c).edit().putString("protected", text).apply(); }
    public static boolean protectedName(Context c, String name) {
        String n = norm(name);
        if(n.isEmpty()) return true;
        for(String line : protects(c).split("\\R")) if(norm(line).equals(n)) return true;
        return false;
    }
    public static String norm(String s) {
        return s == null ? "" : s.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }
    public static List<String> names(Context c, String key) {
        List<String> list = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString(mode(c) + "_" + key, "[]"));
            for(int i=0; i<a.length(); i++) list.add(a.getString(i));
        } catch (JSONException ignored) { }
        return list;
    }
    public static void save(Context c, String key, Iterable<String> names) {
        JSONArray a = new JSONArray();
        for(String s : names) a.put(s);
        sp(c).edit().putString(mode(c) + "_" + key, a.toString()).apply();
    }
    public static void add(Context c, String key, String name) {
        LinkedHashSet<String> set = new LinkedHashSet<>(names(c, key));
        set.add(name); save(c, key, set);
    }
    public static void clearScans(Context c) {
        save(c, "found", Collections.emptyList());
        save(c, "selected", Collections.emptyList());
        save(c, "done", Collections.emptyList());
    }
    public static boolean selected(Context c, String name) {
        for(String s : names(c, "selected")) if(norm(s).equals(norm(name))) return true;
        return false;
    }
    public static boolean done(Context c, String name) {
        for(String s : names(c, "done")) if(norm(s).equals(norm(name))) return true;
        return false;
    }
    public static List<String> remaining(Context c) {
        List<String> list = new ArrayList<>();
        for(String name : names(c, "selected")) {
            if(!protectedName(c, name) && !done(c, name)) list.add(name);
        }
        return list;
    }
    public static void selectAllExceptProtected(Context c) {
        List<String> out = new ArrayList<>();
        for(String name : names(c, "found")) if(!protectedName(c, name)) out.add(name);
        save(c, "selected", out);
    }
    public static void toggleSelected(Context c, String name, boolean selected) {
        Set<String> out = new LinkedHashSet<>(names(c, "selected"));
        out.remove(name);
        if(selected && !protectedName(c, name)) out.add(name);
        save(c, "selected", out);
    }
}
